# cs-wms-outbound-api
**WMS Outbound — Pick Wave, Pack, Manifest, Dispatch**

Spring Boot 3.4.3 | JDK 21 | MySQL 8 | RabbitMQ | JPA | Port 8086

---

## Domain

Manages the physical outbound flow of toys from warehouse to restaurant stores:

```
erp.oms.store-order.allocated
        ↓
  Pick wave CREATED     ──→  erp.wms.outbound.wave.created
        ↓
  ASSIGNED → PICKING
        ↓
  COMPLETED              ──→  erp.wms.outbound.wave.completed
        ↓
  Shipment CREATED       ──→  erp.wms.outbound.shipment.created
        ↓
  PACKED                 ──→  erp.wms.outbound.shipment.packed
        ↓
  MANIFESTED             ──→  erp.wms.outbound.shipment.manifested
        ↓
  DISPATCHED             ──→  erp.wms.outbound.shipment.dispatched
                                      ↑ KEY EVENT consumed by cs-tms-api
                                        to track store delivery
```

---

## Setup

### Step 1 — MySQL Workbench
1. `db/01_ddl_cs_wms_outbound.sql` — creates `cs_wms_outbound`, `wms_outbound_app` user (no DDL), 5 tables
2. `db/02_seed_cs_wms_outbound.sql` — seeds WV-2025-001 (COMPLETED), SHP-2025-001 (DISPATCHED with 4 store lines)

### Step 2 — Fix pom.xml and run (port 8086)
```bash
sed -i '' 's|<n>cs-wms-outbound-api</n>|<name>cs-wms-outbound-api</name>|' pom.xml
mvn clean install -DskipTests
java -jar target/cs-wms-outbound-api-1.0.0-SNAPSHOT.jar
```

### Step 3 — Test
```bash
chmod +x test_cs_wms_outbound_api.sh && ./test_cs_wms_outbound_api.sh
```

---

## REST Endpoints

| Method | Path                                      | Description                              |
|--------|-------------------------------------------|------------------------------------------|
| POST   | /api/v1/pick-waves                        | Create pick wave                         |
| GET    | /api/v1/pick-waves                        | List all waves                           |
| GET    | /api/v1/pick-waves/{id}                   | Get wave with bin lines                  |
| GET    | /api/v1/pick-waves/status/{status}        | Filter by status                         |
| GET    | /api/v1/pick-waves/{id}/events            | Wave audit trail                         |
| POST   | /api/v1/pick-waves/{id}/assign            | → ASSIGNED                               |
| POST   | /api/v1/pick-waves/{id}/start             | → PICKING                                |
| POST   | /api/v1/pick-waves/{id}/complete          | → COMPLETED                              |
| POST   | /api/v1/shipments                         | Create shipment from wave                |
| GET    | /api/v1/shipments                         | List all shipments                       |
| GET    | /api/v1/shipments/{id}                    | Get shipment with store lines            |
| GET    | /api/v1/shipments/status/{status}         | Filter by status                         |
| GET    | /api/v1/shipments/campaign/{code}         | Filter by campaign                       |
| GET    | /api/v1/shipments/{id}/events             | Shipment audit trail                     |
| POST   | /api/v1/shipments/{id}/pack               | → PACKED                                 |
| POST   | /api/v1/shipments/{id}/manifest           | → MANIFESTED (assigns carrier + PRO)     |
| POST   | /api/v1/shipments/{id}/dispatch           | → DISPATCHED (**TMS trigger**)           |
| GET    | /actuator/health                          | Health check                             |

---

## RabbitMQ Events Published

| Event                   | Routing Key                                   |
|-------------------------|-----------------------------------------------|
| Pick wave created       | `erp.wms.outbound.wave.created`               |
| Pick wave completed     | `erp.wms.outbound.wave.completed`             |
| Shipment created        | `erp.wms.outbound.shipment.created`           |
| Shipment packed         | `erp.wms.outbound.shipment.packed`            |
| Shipment manifested     | `erp.wms.outbound.shipment.manifested`        |
| **Shipment dispatched** | **`erp.wms.outbound.shipment.dispatched`**    |

Exchange: `erp.topic.exchange` (shared across all ERP services)

---

## Seeded Data

| Entity       | Number       | Status      | Details                                    |
|--------------|--------------|-------------|---------------------------------------------|
| Pick Wave    | WV-2025-001  | COMPLETED   | 128,000 DINO toys from ZONE-A, 2 bin lines |
| Shipment     | SHP-2025-001 | DISPATCHED  | 4 Midwest store cartons, XPO carrier       |
