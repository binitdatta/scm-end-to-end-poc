# cs-vendor-api
**Vendor Portal ERP — Toy Surprise Campaign Simulation**

Spring Boot 3.4.3 | JDK 21 | MySQL 8 | RabbitMQ | JPA | Port 8082

---

## Domain

Manages the full vendor sourcing lifecycle for toy procurement:
- Vendor registration (China, Vietnam, India, Thailand suppliers)
- RFQ (Request for Quote) issuance for each campaign
- Vendor quote submission and comparison
- Award decision — the `erp.vendor.rfq.awarded` event triggers PO creation in `cs-procurement-api`
- Vendor scorecards

---

## Project Structure

```
cs-vendor-api/
├── db/
│   ├── 01_ddl_cs_vendor.sql       ← Run first (schema + vendor_app user)
│   └── 02_seed_cs_vendor.sql      ← Run second (7 vendors, 2 RFQs, 4 quotes)
├── src/main/java/com/enterprise/csvendor/
│   ├── CsVendorApiApplication.java
│   ├── config/RabbitMQConfig.java
│   ├── controller/
│   │   ├── VendorController.java
│   │   └── RfqController.java
│   ├── dto/
│   │   ├── request/  (CreateVendorRequest, CreateRfqRequest,
│   │   │              SubmitQuoteRequest, AwardRfqRequest)
│   │   └── response/ (ApiResponse, VendorResponse, RfqResponse,
│   │                   QuoteResponse, AwardResponse)
│   ├── entity/
│   │   ├── Vendor.java
│   │   ├── Rfq.java
│   │   ├── RfqVendor.java
│   │   ├── VendorQuote.java
│   │   └── RfqAward.java
│   ├── exception/
│   │   ├── GlobalExceptionHandler.java
│   │   ├── ResourceNotFoundException.java
│   │   ├── InvalidStateException.java
│   │   └── DuplicateResourceException.java
│   ├── messaging/
│   │   ├── VendorEventMessage.java
│   │   └── VendorEventPublisher.java
│   ├── repository/
│   │   ├── VendorRepository.java
│   │   ├── RfqRepository.java
│   │   ├── VendorQuoteRepository.java
│   │   └── RfqAwardRepository.java
│   └── service/
│       ├── VendorService.java
│       └── RfqService.java
└── src/main/resources/
    └── application.properties
```

---

## Setup Steps

### Step 1 — MySQL Workbench
Run as root/admin in order:
1. `db/01_ddl_cs_vendor.sql` — creates `cs_vendor` database, `vendor_app` user (no DDL), 5 tables + indexes
2. `db/02_seed_cs_vendor.sql` — 7 vendors across 4 countries, 2 RFQs, 4 quotes for RFQ-2025-001

### Step 2 — Confirm RabbitMQ is running
```bash
brew services list | grep rabbitmq
```

### Step 3 — Open in IntelliJ
File → Open → `cs-vendor-api`. Maven auto-imports. Enable Lombok annotation processing.

### Step 4 — Run
```bash
mvn spring-boot:run
# or
mvn clean install -DskipTests && java -jar target/cs-vendor-api-1.0.0-SNAPSHOT.jar
```
Starts on **port 8082**. Both cs-crm-api (8081) and cs-vendor-api (8082) can run simultaneously.

### Step 5 — Test
```bash
chmod +x test_cs_vendor_api.sh && ./test_cs_vendor_api.sh
```

---

## REST Endpoints

| Method | Path                              | Description                              |
|--------|-----------------------------------|------------------------------------------|
| POST   | /api/v1/vendors                   | Register vendor + publish event          |
| GET    | /api/v1/vendors                   | List all vendors                         |
| GET    | /api/v1/vendors/{id}              | Get vendor by external ID                |
| GET    | /api/v1/vendors/country/{country} | Filter active vendors by country         |
| PATCH  | /api/v1/vendors/{id}/scorecard    | Update scorecard rating                  |
| POST   | /api/v1/rfqs                      | Create RFQ (DRAFT)                       |
| GET    | /api/v1/rfqs                      | List all RFQs                            |
| GET    | /api/v1/rfqs/{id}                 | Get RFQ by external ID                   |
| POST   | /api/v1/rfqs/{id}/open            | DRAFT → OPEN + publish event             |
| POST   | /api/v1/rfqs/{id}/quotes          | Vendor submits quote + publish event     |
| GET    | /api/v1/rfqs/{id}/quotes          | List all quotes for RFQ                  |
| POST   | /api/v1/rfqs/{id}/award           | Award RFQ → KEY event for procurement    |
| GET    | /api/v1/rfqs/{id}/award           | Get award record                         |
| POST   | /api/v1/rfqs/{id}/cancel          | Cancel RFQ + publish event               |
| GET    | /actuator/health                  | Health check                             |

---

## RabbitMQ Events Published

| Event                        | Routing Key                      | Consumed by          |
|------------------------------|----------------------------------|----------------------|
| Vendor registered            | `erp.vendor.vendor.created`      | Control Tower        |
| RFQ opened for bidding       | `erp.vendor.rfq.opened`          | Control Tower        |
| Vendor quote submitted       | `erp.vendor.quote.submitted`     | Control Tower        |
| **RFQ awarded to vendor**    | **`erp.vendor.rfq.awarded`**     | **cs-procurement-api** |
| RFQ cancelled                | `erp.vendor.rfq.cancelled`       | Control Tower        |

Exchange: `erp.topic.exchange` (Topic, durable, shared with cs-crm-api)

---

## Seeded Reference Data

**Vendors**
| Code        | Name                              | Country  | Rating | Lead Time |
|-------------|-----------------------------------|----------|--------|-----------|
| VND-CN-001  | Shenzhen BrightToy Manufacturing  | CHINA    | 4.20   | 45 days   |
| VND-VN-001  | Ho Chi Minh Playthings Ltd.       | VIETNAM  | 4.50   | 38 days   |
| VND-IN-001  | Pune Creative Toys Pvt. Ltd.      | INDIA    | 3.90   | 55 days   |
| VND-TH-001  | Bangkok Fun Factory Co. Ltd.      | THAILAND | 4.75   | 42 days   |
| VND-CN-002  | Guangzhou PackMaster Co.          | CHINA    | 4.00   | 30 days   |
| VND-VN-002  | Hanoi Precision Plastics          | VIETNAM  | 4.10   | 40 days   |
| VND-IN-002  | Chennai Toy Crafts Ltd.           | INDIA    | 3.20   | 60 days   |

**RFQs**
| RFQ Number    | Campaign        | Qty       | Status       |
|---------------|-----------------|-----------|--------------|
| RFQ-2025-001  | SUMMER25-TOY    | 500,000   | OPEN (4 quotes received) |
| RFQ-2025-002  | HOLIDAY25-TOY   | 1,200,000 | DRAFT        |
