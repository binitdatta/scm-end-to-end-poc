# cs-crm-api
**CRM & Campaign Management ERP — Toy Surprise Campaign Simulation**

Spring Boot 3.4.3 | JDK 21 | MySQL 8 | RabbitMQ | JPA

---

## Project Structure

```
cs-crm-api/
├── db/
│   ├── 01_ddl_cs_crm.sql        ← Run first in MySQL Workbench (schema + user)
│   └── 02_seed_cs_crm.sql       ← Run second (reference data)
├── src/main/java/com/enterprise/cscrm/
│   ├── CsCrmApiApplication.java
│   ├── config/
│   │   └── RabbitMQConfig.java
│   ├── controller/
│   │   ├── CampaignController.java
│   │   └── CustomerController.java
│   ├── dto/
│   │   ├── request/  (CreateCampaignRequest, LaunchCampaignRequest, CreateCustomerRequest)
│   │   └── response/ (ApiResponse, CampaignResponse, CustomerResponse)
│   ├── entity/
│   │   ├── Campaign.java
│   │   ├── CampaignCustomer.java
│   │   ├── CampaignEvent.java
│   │   └── Customer.java
│   ├── exception/
│   │   ├── GlobalExceptionHandler.java
│   │   ├── ResourceNotFoundException.java
│   │   ├── InvalidStateException.java
│   │   └── DuplicateResourceException.java
│   ├── messaging/
│   │   ├── CampaignEventMessage.java
│   │   └── CampaignEventPublisher.java
│   ├── repository/
│   │   ├── CampaignRepository.java
│   │   ├── CampaignEventRepository.java
│   │   └── CustomerRepository.java
│   └── service/
│       ├── CampaignService.java
│       └── CustomerService.java
└── src/main/resources/
    └── application.properties
```

---

## Setup Steps

### Step 1 — Start RabbitMQ

```bash
brew services start rabbitmq
rabbitmq-plugins enable rabbitmq_management
```

Verify at: http://localhost:15672 (guest / guest)

---

### Step 2 — Run DDL in MySQL Workbench

Open MySQL Workbench and connect to your local MySQL 8 instance as root/admin.

**Run `db/01_ddl_cs_crm.sql` first:**
- Creates the `cs_crm` database
- Creates the `crm_app` application user with SELECT/INSERT/UPDATE/DELETE only
- Creates all tables: customers, campaigns, campaign_events, campaign_customers
- Creates all indexes

**Then run `db/02_seed_cs_crm.sql`:**
- Inserts 10 sample customers
- Inserts 3 campaigns in DRAFT status
- Enrolls GOLD/PLATINUM customers into the Summer Surprise campaign

> The app user `crm_app` has NO DDL privileges. Spring Boot is configured with
> `spring.jpa.hibernate.ddl-auto=none` — it will never attempt to create or
> alter tables.

---

### Step 3 — Open in IntelliJ

1. File → Open → select the `cs-crm-api` folder
2. IntelliJ will detect the `pom.xml` and import the Maven project automatically
3. Wait for Maven to download dependencies (first time only)
4. Enable annotation processing for Lombok:
   - Preferences → Build, Execution, Deployment → Compiler → Annotation Processors
   - Check "Enable annotation processing"

---

### Step 4 — Verify application.properties

The datasource is pre-configured to connect as `crm_app`. If you changed
the password in the DDL script, update it here:

```
spring.datasource.password=CrmApp#2025!
```

The app runs on **port 8081** to leave 8080 free for other services.

---

### Step 5 — Run the Application

From IntelliJ: Right-click `CsCrmApiApplication.java` → Run

Or from terminal:
```bash
cd cs-crm-api
mvn spring-boot:run
```

Confirm startup log contains:
```
Started CsCrmApiApplication on port 8081
```

---

### Step 6 — Run the Curl Test Script

```bash
chmod +x test_cs_crm_api.sh
./test_cs_crm_api.sh
```

This runs the full lifecycle:
1. Creates 2 new customers → publishes `erp.crm.customer.created`
2. Creates a new campaign in DRAFT
3. Launches it → publishes `erp.crm.campaign.launched`
4. Pauses it → publishes `erp.crm.campaign.paused`
5. Attempts invalid re-launch (expects 409)
6. Completes it → publishes `erp.crm.campaign.completed`
7. Tests duplicate email guard (expects 409)
8. Checks actuator health

---

## RabbitMQ Events Published

| Action            | Routing Key                      |
|-------------------|----------------------------------|
| Campaign launched | `erp.crm.campaign.launched`      |
| Campaign paused   | `erp.crm.campaign.paused`        |
| Campaign completed| `erp.crm.campaign.completed`     |
| Customer created  | `erp.crm.customer.created`       |

Exchange: `erp.topic.exchange` (Topic, durable)

The Control Tower Flask app subscribes to `erp.crm.#` to capture all CRM events.

---

## REST Endpoints

| Method | Path                                    | Description                    |
|--------|-----------------------------------------|--------------------------------|
| POST   | /api/v1/campaigns                       | Create campaign (DRAFT)        |
| GET    | /api/v1/campaigns                       | List all campaigns             |
| GET    | /api/v1/campaigns/{externalId}          | Get campaign by ID             |
| POST   | /api/v1/campaigns/{externalId}/launch   | DRAFT → ACTIVE + publish event |
| POST   | /api/v1/campaigns/{externalId}/pause    | ACTIVE → PAUSED + publish event|
| POST   | /api/v1/campaigns/{externalId}/complete | → COMPLETED + publish event    |
| POST   | /api/v1/customers                       | Create customer + publish event|
| GET    | /api/v1/customers                       | List all customers             |
| GET    | /api/v1/customers/{externalId}          | Get customer by ID             |
| GET    | /actuator/health                        | Health check                   |
