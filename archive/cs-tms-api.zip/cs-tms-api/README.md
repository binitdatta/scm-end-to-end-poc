# cs-tms-api
**TMS — Delivery Load Tracking, Store Delivery, Proof of Delivery**

Spring Boot 3.4.3 | JDK 21 | MySQL 8 | RabbitMQ | JPA | Port 8087

---

## Domain

The final Spring Boot service in the supply chain. Receives dispatched shipments
from WMS Outbound, tracks carrier delivery to each restaurant store, and issues
Proof of Delivery (POD) confirmation.

```
erp.wms.outbound.shipment.dispatched
        ↓
  Delivery Load CREATED      ──→  erp.tms.load.created
        ↓
  ASSIGNED (driver + truck)  ──→  erp.tms.load.assigned
        ↓
  IN_TRANSIT                 ──→  erp.tms.load.in-transit
                             ──→  erp.tms.delivery.out-for-delivery
        ↓
  POD confirmed per store    (each store individually)
        ↓
  ALL stores POD_CONFIRMED
        ↓
  COMPLETED (auto)           ──→  erp.tms.load.completed
                             ──→  erp.tms.delivery.pod-confirmed  ← FINAL EVENT
                                        ↑ consumed by Flask Control Tower
                                          for BI dashboards + analytics
```

---

## Setup

### Step 1 — MySQL Workbench
1. `db/01_ddl_cs_tms.sql` — creates `cs_tms` DB, `tms_app` user (no DDL), 4 tables
2. `db/02_seed_cs_tms.sql` — seeds LOAD-2025-001 (COMPLETED, 4 stores POD_CONFIRMED), transit events, audit trail

### Step 2 — Fix pom.xml and run (port 8087)
```bash
sed -i '' 's|<n>cs-tms-api</n>|<name>cs-tms-api</name>|' pom.xml
mvn clean install -DskipTests
java -jar target/cs-tms-api-1.0.0-SNAPSHOT.jar
```

### Step 3 — Test
```bash
chmod +x test_cs_tms_api.sh && ./test_cs_tms_api.sh
```

---

## REST Endpoints

| Method | Path                                                       | Description                            |
|--------|------------------------------------------------------------|----------------------------------------|
| POST   | /api/v1/delivery-loads                                     | Create delivery load                   |
| GET    | /api/v1/delivery-loads                                     | List all loads                         |
| GET    | /api/v1/delivery-loads/{id}                                | Get load with store deliveries         |
| GET    | /api/v1/delivery-loads/status/{status}                     | Filter by status                       |
| GET    | /api/v1/delivery-loads/campaign/{code}                     | Filter by campaign                     |
| GET    | /api/v1/delivery-loads/{id}/transit-events                 | Carrier tracking milestones            |
| GET    | /api/v1/delivery-loads/{id}/events                         | TMS audit trail                        |
| POST   | /api/v1/delivery-loads/{id}/assign                         | → ASSIGNED (driver + truck)            |
| POST   | /api/v1/delivery-loads/{id}/in-transit                     | → IN_TRANSIT                           |
| POST   | /api/v1/delivery-loads/{id}/transit-events                 | Append carrier milestone               |
| POST   | /api/v1/delivery-loads/{id}/store-deliveries/{sdId}/pod    | Confirm POD at store                   |
| GET    | /actuator/health                                           | Health check                           |

---

## RabbitMQ Events Published

| Event                       | Routing Key                              |
|-----------------------------|------------------------------------------|
| Load created                | `erp.tms.load.created`                  |
| Driver assigned             | `erp.tms.load.assigned`                 |
| Load in transit             | `erp.tms.load.in-transit`               |
| Out for delivery            | `erp.tms.delivery.out-for-delivery`     |
| Load completed              | `erp.tms.load.completed`                |
| **POD confirmed (all stores)** | **`erp.tms.delivery.pod-confirmed`** |

Exchange: `erp.topic.exchange` (shared across all ERP services)

---

## Seeded Data

| Entity          | Number         | Status    | Details                                          |
|-----------------|----------------|-----------|---------------------------------------------------|
| Delivery Load   | LOAD-2025-001  | COMPLETED | Midwest, XPO, 4 stores all POD_CONFIRMED          |
| Store Deliveries| 4 Midwest stores| POD_CONFIRMED | Chicago, Naperville, Milwaukee, Indianapolis  |
| Transit Events  | 4 milestones   | —         | PICKUP → IN_TRANSIT → OUT_FOR_DELIVERY → DELIVERED|

---

## Full Supply Chain Summary

| # | Service              | Port | Key Event Published                              |
|---|----------------------|------|--------------------------------------------------|
| 1 | cs-crm-api           | 8081 | `erp.crm.campaign.launched`                      |
| 2 | cs-vendor-api        | 8082 | `erp.vendor.rfq.awarded`                         |
| 3 | cs-procurement-api   | 8083 | `erp.procurement.po.ready-to-ship`               |
| 4 | cs-wms-inbound-api   | 8084 | `erp.wms.inbound.putaway.completed`              |
| 5 | cs-oms-api           | 8085 | `erp.oms.store-order.allocated`                  |
| 6 | cs-wms-outbound-api  | 8086 | `erp.wms.outbound.shipment.dispatched`           |
| 7 | **cs-tms-api**       | **8087** | **`erp.tms.delivery.pod-confirmed`** ← FINAL |
| 8 | Flask Control Tower  | 5000 | BI dashboards + Anthropic NL query engine        |
