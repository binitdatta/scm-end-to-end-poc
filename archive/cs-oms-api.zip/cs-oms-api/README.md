# cs-oms-api
**OMS — Store Order Management & Allocation**

Spring Boot 3.4.3 | JDK 21 | MySQL 8 | RabbitMQ | JPA | Port 8085

---

## Domain

Manages store-level toy allocation across the food chain's 3,200 US restaurant locations:

```
erp.wms.inbound.putaway.completed
        ↓ (OMS updates inventory view)
  Store order DRAFT
        ↓
  SUBMITTED                ──→  erp.oms.store-order.submitted
        ↓
  ALLOCATED                ──→  erp.oms.store-order.allocated  ← WMS Outbound pick wave
  (splits qty across stores)
        ↓
  PICKING                  ──→  erp.oms.store-order.picking
        ↓
  SHIPPED                  ──→  erp.oms.store-order.shipped
        ↓
  DELIVERED                ──→  erp.oms.store-order.delivered
```

---

## Project Structure

```
cs-oms-api/
├── db/
│   ├── 01_ddl_cs_oms.sql          ← Run first (6 tables + oms_app user)
│   └── 02_seed_cs_oms.sql         ← Run second (regions, stores, inventory, 2 orders)
├── src/main/java/com/enterprise/csoms/
│   ├── CsOmsApiApplication.java
│   ├── config/RabbitMQConfig.java
│   ├── controller/
│   │   ├── StoreOrderController.java
│   │   ├── InventoryController.java
│   │   └── StoreController.java
│   ├── dto/
│   │   ├── request/  (CreateStoreOrderRequest, AllocateOrderRequest, UpdateInventoryRequest)
│   │   └── response/ (ApiResponse, StoreOrderResponse, RegionResponse,
│   │                   StoreResponse, InventoryAvailabilityResponse, OrderEventResponse)
│   ├── entity/
│   │   ├── StoreRegion.java
│   │   ├── Store.java
│   │   ├── StoreOrder.java
│   │   ├── StoreOrderLine.java
│   │   ├── InventoryAvailability.java
│   │   └── OrderEvent.java
│   ├── exception/ (4 exception classes + GlobalExceptionHandler)
│   ├── messaging/
│   │   ├── OmsEventMessage.java
│   │   └── OmsEventPublisher.java
│   ├── repository/ (6 repositories)
│   └── service/
│       ├── StoreOrderService.java
│       ├── InventoryService.java
│       └── StoreService.java
└── src/main/resources/
    └── application.properties
```

---

## Setup

### Step 1 — MySQL Workbench
Run as admin in order:
1. `db/01_ddl_cs_oms.sql` — creates `cs_oms` database, `oms_app` user (no DDL), 6 tables
2. `db/02_seed_cs_oms.sql` — seeds 6 regions, 20 stores, inventory for 2 SKUs, 2 store orders

### Step 2 — Run (port 8085)
```bash
# Fix the <n> tag before building (known pom.xml issue)
sed -i '' 's|<n>cs-oms-api</n>|<name>cs-oms-api</name>|' pom.xml
mvn clean install -DskipTests
java -jar target/cs-oms-api-1.0.0-SNAPSHOT.jar
```

All five services can now run simultaneously:
- cs-crm-api        → 8081
- cs-vendor-api     → 8082
- cs-procurement-api → 8083
- cs-wms-inbound-api → 8084
- cs-oms-api        → 8085

### Step 3 — Test
```bash
chmod +x test_cs_oms_api.sh && ./test_cs_oms_api.sh
```

---

## REST Endpoints

| Method | Path                                          | Description                           |
|--------|-----------------------------------------------|---------------------------------------|
| GET    | /api/v1/regions                               | List all 6 regions                    |
| GET    | /api/v1/regions/{code}                        | Get region by code                    |
| GET    | /api/v1/regions/{code}/stores                 | Stores in a region                    |
| GET    | /api/v1/stores                                | List all stores                       |
| POST   | /api/v1/inventory/update                      | Sync inventory from WMS putaway       |
| GET    | /api/v1/inventory/campaign/{code}             | All SKUs for a campaign               |
| GET    | /api/v1/inventory/sku/{sku}/campaign/{code}   | Single SKU availability               |
| POST   | /api/v1/store-orders                          | Create store order (DRAFT)            |
| GET    | /api/v1/store-orders                          | List all orders                       |
| GET    | /api/v1/store-orders/{id}                     | Get order with store lines            |
| GET    | /api/v1/store-orders/status/{status}          | Filter by status                      |
| GET    | /api/v1/store-orders/campaign/{code}          | Filter by campaign                    |
| GET    | /api/v1/store-orders/{id}/events              | Full audit trail                      |
| POST   | /api/v1/store-orders/{id}/submit              | → SUBMITTED                           |
| POST   | /api/v1/store-orders/{id}/allocate            | → ALLOCATED (**WMS Outbound trigger**)|
| POST   | /api/v1/store-orders/{id}/picking             | → PICKING                             |
| POST   | /api/v1/store-orders/{id}/shipped             | → SHIPPED                             |
| POST   | /api/v1/store-orders/{id}/delivered           | → DELIVERED                           |
| POST   | /api/v1/store-orders/{id}/cancel              | → CANCELLED (releases inventory)      |
| GET    | /actuator/health                              | Health check                          |

---

## RabbitMQ Events Published

| Event                   | Routing Key                             |
|-------------------------|-----------------------------------------|
| Inventory synced        | `erp.oms.inventory.updated`             |
| Order created           | `erp.oms.store-order.created`           |
| Order submitted         | `erp.oms.store-order.submitted`         |
| **Order allocated**     | **`erp.oms.store-order.allocated`**     |
| Order picking           | `erp.oms.store-order.picking`           |
| Order shipped           | `erp.oms.store-order.shipped`           |
| Order delivered         | `erp.oms.store-order.delivered`         |
| Order cancelled         | `erp.oms.store-order.cancelled`         |

Exchange: `erp.topic.exchange` (shared across all ERP services)

---

## Seeded Reference Data

**Regions (6)**

| Code         | Name                  | Stores | DC               |
|--------------|-----------------------|--------|------------------|
| US-MIDWEST   | Midwest United States | 640    | DC-CHICAGO       |
| US-WEST      | Western United States | 580    | DC-LOS-ANGELES   |
| US-SOUTHEAST | Southeast US          | 520    | DC-ATLANTA       |
| US-NORTHEAST | Northeast US          | 480    | DC-NEW-YORK      |
| US-SOUTHWEST | Southwest US          | 440    | DC-DALLAS        |
| US-NORTHWEST | Northwest US          | 540    | DC-SEATTLE       |

**Inventory available**

| SKU                  | Campaign      | Available | Reserved | Remaining |
|----------------------|---------------|-----------|----------|-----------|
| TOY-DINO-MIX-001     | SUMMER25-TOY  | 499,800   | 128,000  | 371,800   |
| TOY-SPACE-MIX-001    | SUMMER25-TOY  | 249,950   | 0        | 249,950   |

**Seeded Orders**

| Order         | Region       | SKU               | Qty     | Status    |
|---------------|--------------|-------------------|---------|-----------|
| ORD-2025-001  | US-MIDWEST   | TOY-DINO-MIX-001  | 128,000 | ALLOCATED |
| ORD-2025-002  | US-WEST      | TOY-DINO-MIX-001  | 116,000 | DRAFT     |
