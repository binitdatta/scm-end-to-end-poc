# cs-wms-inbound-api
**WMS Inbound — ASN, Receiving, Putaway, Inventory**

Spring Boot 3.4.3 | JDK 21 | MySQL 8 | RabbitMQ | JPA | Port 8084

---

## Domain

Manages the physical inbound flow of toys from vendor to warehouse:

```
erp.procurement.po.ready-to-ship
        ↓
  ASN created (CREATED)    ──→  erp.wms.inbound.asn.created
        ↓
  Dock scheduled (SCHEDULED) → erp.wms.inbound.asn.scheduled
        ↓
  IN_TRANSIT
        ↓
  ARRIVED                  ──→  erp.wms.inbound.shipment.arrived
        ↓
  RECEIVED (physical count)──→  erp.wms.inbound.receiving.completed
        ↓
  PUTAWAY_COMPLETED         ──→  erp.wms.inbound.putaway.completed
                                      ↑ KEY EVENT consumed by cs-oms-api
                                        to mark inventory available
                                        for store allocation
```

---

## Setup

### Step 1 — MySQL Workbench
1. `db/01_ddl_cs_wms_inbound.sql` — creates `cs_wms_inbound` DB, `wms_inbound_app` user (no DDL), 5 tables
2. `db/02_seed_cs_wms_inbound.sql` — seeds 2 ASNs, receiving record, putaway tasks, inventory locations

### Step 2 — Run (port 8084)
```bash
mvn clean install -DskipTests
java -jar target/cs-wms-inbound-api-1.0.0-SNAPSHOT.jar
```

### Step 3 — Test
```bash
chmod +x test_cs_wms_inbound_api.sh && ./test_cs_wms_inbound_api.sh
```

---

## REST Endpoints

| Method | Path                                   | Description                              |
|--------|----------------------------------------|------------------------------------------|
| POST   | /api/v1/asns                           | Create ASN                               |
| GET    | /api/v1/asns                           | List all ASNs                            |
| GET    | /api/v1/asns/{id}                      | Get ASN                                  |
| GET    | /api/v1/asns/status/{status}           | Filter by status                         |
| POST   | /api/v1/asns/{id}/schedule             | → SCHEDULED (dock booked)                |
| POST   | /api/v1/asns/{id}/in-transit           | → IN_TRANSIT                             |
| POST   | /api/v1/asns/{id}/arrived              | → ARRIVED                                |
| POST   | /api/v1/asns/{id}/receive              | → RECEIVED (physical count)              |
| GET    | /api/v1/asns/{id}/receiving            | Get receiving record                     |
| POST   | /api/v1/asns/{id}/putaway              | → PUTAWAY_COMPLETED (**OMS trigger**)    |
| GET    | /api/v1/asns/{id}/events               | Full audit trail                         |
| GET    | /api/v1/inventory/sku/{sku}            | Inventory by SKU (all bins)              |
| GET    | /api/v1/inventory/campaign/{code}      | Inventory by campaign                    |
| GET    | /api/v1/inventory/sku/{sku}/available  | Total available quantity                 |
| GET    | /api/v1/inventory/campaign/{code}/on-hand | Total on-hand quantity                |
| GET    | /actuator/health                       | Health check                             |

---

## RabbitMQ Events

| Event                   | Routing Key                                 |
|-------------------------|---------------------------------------------|
| ASN created             | `erp.wms.inbound.asn.created`               |
| Dock scheduled          | `erp.wms.inbound.asn.scheduled`             |
| Shipment arrived        | `erp.wms.inbound.shipment.arrived`          |
| Receiving completed     | `erp.wms.inbound.receiving.completed`       |
| **Putaway completed**   | **`erp.wms.inbound.putaway.completed`**     |

Exchange: `erp.topic.exchange` (shared across all ERP services)

---

## Seeded Data

| ASN Number   | PO           | Vendor              | SKU                  | Qty       | Status             |
|--------------|--------------|---------------------|----------------------|-----------|--------------------|
| ASN-2025-001 | PO-2025-001  | Ho Chi Minh Playthings | TOY-DINO-MIX-001  | 500,000   | PUTAWAY_COMPLETED  |
| ASN-2025-002 | PO-2025-002  | Shenzhen BrightToy  | TOY-HOLIDAY-MIX-001  | 1,200,000 | SCHEDULED          |

Seeded inventory (from ASN-2025-001):
- `BIN-A-01-001`: 250,000 units available
- `BIN-A-02-001`: 249,800 units available
- Total available: 499,800 units of `TOY-DINO-MIX-001`
