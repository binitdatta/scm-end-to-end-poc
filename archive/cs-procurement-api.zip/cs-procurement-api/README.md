# cs-procurement-api
**Procurement ERP — Purchase Order & Invoice Management**

Spring Boot 3.4.3 | JDK 21 | MySQL 8 | RabbitMQ | JPA | Port 8083

---

## Domain

Manages the full PO lifecycle after a vendor RFQ is awarded in `cs-vendor-api`:

```
erp.vendor.rfq.awarded
        ↓
  PO created (DRAFT)
        ↓
     APPROVED  ──→  erp.procurement.po.approved
        ↓
  SENT_TO_VENDOR ─→  erp.procurement.po.sent
        ↓
  ACKNOWLEDGED   ──→  erp.procurement.po.acknowledged
        ↓
  IN_PRODUCTION  ──→  erp.procurement.po.in-production
        ↓
  READY_TO_SHIP  ──→  erp.procurement.po.ready-to-ship  ← WMS Inbound creates ASN
        ↓
   COMPLETED     ──→  erp.procurement.po.completed

  Invoice sub-flow (parallel):
    RECEIVED → APPROVED → PAID
    Each step publishes its own erp.procurement.invoice.* event
```

---

## Project Structure

```
cs-procurement-api/
├── db/
│   ├── 01_ddl_cs_procurement.sql    ← Run first (4 tables + procurement_app user)
│   └── 02_seed_cs_procurement.sql   ← Run second (2 POs, 3 line items, audit events)
├── src/main/java/com/enterprise/csprocurement/
│   ├── CsProcurementApiApplication.java
│   ├── config/RabbitMQConfig.java
│   ├── controller/
│   │   ├── PurchaseOrderController.java
│   │   └── InvoiceController.java
│   ├── dto/
│   │   ├── request/  (CreatePoRequest, ApprovePoRequest, CreateInvoiceRequest)
│   │   └── response/ (ApiResponse, PoResponse, InvoiceResponse, PoEventResponse)
│   ├── entity/
│   │   ├── PurchaseOrder.java
│   │   ├── PoLineItem.java
│   │   ├── PoEvent.java
│   │   └── Invoice.java
│   ├── exception/ (GlobalExceptionHandler + 3 exception classes)
│   ├── messaging/
│   │   ├── ProcurementEventMessage.java
│   │   └── ProcurementEventPublisher.java
│   ├── repository/ (PurchaseOrderRepository, PoEventRepository, InvoiceRepository)
│   └── service/
│       ├── PurchaseOrderService.java
│       └── InvoiceService.java
└── src/main/resources/
    └── application.properties
```

---

## Setup

### Step 1 — MySQL Workbench
Run as admin in order:
1. `db/01_ddl_cs_procurement.sql` — database, `procurement_app` user (no DDL), 4 tables
2. `db/02_seed_cs_procurement.sql` — PO-2025-001 (APPROVED, Vietnam vendor, 500k dino toys), PO-2025-002 (DRAFT, China vendor, 1.2M figurines)

### Step 2 — Run (port 8083)
```bash
mvn clean install -DskipTests
java -jar target/cs-procurement-api-1.0.0-SNAPSHOT.jar
```

All three services can run simultaneously:
- cs-crm-api       → port 8081
- cs-vendor-api    → port 8082
- cs-procurement-api → port 8083

### Step 3 — Test
```bash
chmod +x test_cs_procurement_api.sh && ./test_cs_procurement_api.sh
```

---

## REST Endpoints

| Method | Path                                          | Description                        |
|--------|-----------------------------------------------|------------------------------------|
| POST   | /api/v1/purchase-orders                       | Create PO (DRAFT)                  |
| GET    | /api/v1/purchase-orders                       | List all POs                       |
| GET    | /api/v1/purchase-orders/{id}                  | Get PO                             |
| GET    | /api/v1/purchase-orders/status/{status}       | Filter by status                   |
| GET    | /api/v1/purchase-orders/{id}/events           | Full audit trail                   |
| POST   | /api/v1/purchase-orders/{id}/approve          | → APPROVED                         |
| POST   | /api/v1/purchase-orders/{id}/send             | → SENT_TO_VENDOR                   |
| POST   | /api/v1/purchase-orders/{id}/acknowledge      | → ACKNOWLEDGED                     |
| POST   | /api/v1/purchase-orders/{id}/in-production    | → IN_PRODUCTION                    |
| POST   | /api/v1/purchase-orders/{id}/ready-to-ship    | → READY_TO_SHIP (**WMS trigger**)  |
| POST   | /api/v1/purchase-orders/{id}/complete         | → COMPLETED                        |
| POST   | /api/v1/purchase-orders/{id}/cancel           | → CANCELLED                        |
| POST   | /api/v1/purchase-orders/{id}/invoices         | Receive vendor invoice             |
| GET    | /api/v1/purchase-orders/{id}/invoices         | List invoices for PO               |
| GET    | /api/v1/invoices/{id}                         | Get invoice                        |
| POST   | /api/v1/invoices/{id}/approve                 | → APPROVED                         |
| POST   | /api/v1/invoices/{id}/pay                     | → PAID                             |
| GET    | /actuator/health                              | Health check                       |

---

## RabbitMQ Events Published

| Event                      | Routing Key                               |
|----------------------------|-------------------------------------------|
| PO created                 | `erp.procurement.po.created`              |
| PO approved                | `erp.procurement.po.approved`             |
| PO sent to vendor          | `erp.procurement.po.sent`                 |
| PO acknowledged            | `erp.procurement.po.acknowledged`         |
| PO in production           | `erp.procurement.po.in-production`        |
| **PO ready to ship**       | **`erp.procurement.po.ready-to-ship`**    |
| PO completed               | `erp.procurement.po.completed`            |
| PO cancelled               | `erp.procurement.po.cancelled`            |
| Invoice received           | `erp.procurement.invoice.received`        |
| Invoice approved           | `erp.procurement.invoice.approved`        |
| Invoice paid               | `erp.procurement.invoice.paid`            |

Exchange: `erp.topic.exchange` (shared with cs-crm-api and cs-vendor-api)

---

## Seeded Data

| PO Number   | Vendor              | Country | Qty       | Value      | Status   |
|-------------|---------------------|---------|-----------|------------|----------|
| PO-2025-001 | Ho Chi Minh Playthings | VIETNAM | 500,000 | $410,000 | APPROVED |
| PO-2025-002 | Shenzhen BrightToy  | CHINA   | 1,200,000 | $936,000 | DRAFT    |
